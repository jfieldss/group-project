<?php
define('DB_SETTINGS',[
	'host'=>'localhost',
	'db'=>'sfs',
	'user'=>'root',
	'pass'=>''
]);
session_start();