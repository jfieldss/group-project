
<?php
require_once('template.php');
require_once('settings.php');
require_once('MySQLDB.php');
require_once('Post.php');

Template::showHeader('Smiles for Seniors Events');

$pdo=MySQLDB::connect();

$posts=$pdo->query('SELECT * FROM posts');

while($post=$posts->fetch()){
	$p=new Post($post);
	$p->showPreview();
}
Template::showFooter();
?>