<?php
require_once('../settings.php');
require_once('../MySQLDB.php');
require_once('../Post.php');

$post=new Post(null,$_GET['id']);

require_once('../template.php');
Template::showHeader($post->title);
$post->showDetail();
?>
<a class="btn btn-outline-secondary" href="index.php">Go back</a>
<?php

Template::showFooter();