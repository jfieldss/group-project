<?php
require_once('template.php');
Template::showHeader('Welcome');
Template::showFooter();
?>


<!DOCTYPE html>
<html>
<head>
<style>
h1 { 
  display: block;
  font-size: 2em;
  margin-top: 0.67em;
  margin-bottom: 0.67em;
  margin-left: 0;
  margin-right: 0;
  font-weight: bold;
}
</style>
</head>
<body>

<title>Smiles for Seniors</title>

<h1 style="text-align:center">Smiles for Seniors Events</h1>

</body>
</html>