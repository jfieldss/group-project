<?php
class JSON {
	public static function write($file, $data) {
		
	}
	
	public static function read($file) {
		
	}
}