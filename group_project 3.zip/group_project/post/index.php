<?php
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/settings.php');
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/template.php');

require_once('/opt/lampp/htdocs/strzelewiczSam_A12/MySQLDB.php');
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/Post2.php');

Template::showHeader('Welcome');
?>
<p>Welcome to hotel booking</p>
<?php

$pdo=MySQLDB::connect();
$posts=$pdo->query('SELECT * FROM posts');
while($post=$posts->fetch()){
	$p=new Post2($post);
	$p->showPreview();
}
Template::showFooter();