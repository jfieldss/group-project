<?php

class User{
	public $email;
	public $password;
	public $role;
	public $first_name;
	public $last_name;
	
	public function __construct($first=null,$last=null,$email=null,$password=null){
		$this->first_name=$first;
		$this->last_name=$last;
		$this->email=$email;
		$this->password=$password;
		
	}
	public function create($data){
		if(!isset($data['email']{0}) || !isset($data['password']{0}) || !isset($data['first_name']{0}) || !isset($data['last_name']{0})) return 'Some fields are missing';
		if(!filter_var($data['email'],FILTER_VALIDATE_EMAIL)) return 'The email address is not valid';
		require_once('MySQLDB.php');
		$pdo=MySQLDB::connect();
		$query=$pdo->prepare('SELECT ID FROM users WHERE email=?');
		$query->execute([$data['email']]);
		if($query->rowCount()>0) return 'The user is already registered';
		$data['password']=password_hash($data['password'],PASSWORD_DEFAULT);
		$query=$pdo->prepare('INSERT INTO users(email,password,first_name,last_name) VALUES(?,?,?,?)');
		$query->execute([$data['email'],$data['password'],$data['first_name'],$data['last_name']]);
		return '';
	}
	
	public function update($data){
		if(!isset($data['email']{0}) || !isset($data['password']{0}) || !isset($data['role']{0}) || !isset($data['first_name']{0}) || !isset($data['last_name']{0})) return 'Some fields are missing';
		if(!filter_var($data['email'],FILTER_VALIDATE_EMAIL)) return 'The email address is not valid';
		require_once('MySQLDB.php');
		$pdo=MySQLDB::connect();
		$query=$pdo->prepare('UPDATE users SET first_name=?,last_name=?,email=?,password=?,role=? ,status=? WHERE ID=?');
		$query->execute([$data['first_name'],$data['last_name'],$data['email'],$data['password'],$data['role'],$data['status'],$_GET['id']]);
		return '';
	}
	
	public function delete($id){
		require_once('MySQLDB.php');
		$pdo=MySQLDB::connect();
		$query=$pdo->prepare('UPDATE users SET status=-1 WHERE ID=?');
		$query->execute([$id]);
	}
	
	public function detail(){
		// show user's details;
	}
	
	public function showPreview($id){
		return '<tr><td>'.$this->first_name.' '.$this->last_name.'</td><td>'.$this->email.'</td><td><a class="btn btn-sm btn-primary" href="admin/users/detail.php?id='.$id.'">See details</a></td></tr>';
	}
	public function showTableRow(){
		echo '<tr>';
		echo '<td>'.$this->ID.'</td>';
		echo '<td>'.$this->email.'</td>';
		echo '<td>'.$this->password.'</td>';
		echo '<td><a href="admin/users/edit.php?id='.$this->ID.'">Edit</a></td>';
		echo '<tr>';
	}
}