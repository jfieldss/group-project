<?php
require_once('settings.php');
require_once('MySQLDB.php');
require_once('User.php');

class Post{
	public $ID;
	public $title;
	private $author_ID;
	public $content;
	private $date_created;
	private $status;
	private $date_published;
	private $author;
	
	function __construct($data=null,$id=null){
		if($data==null && $id==null) return;
		if(isset($id)){

			$pdo=MySQLDB::connect();
			$query=$pdo->prepare('SELECT * FROM posts WHERE ID=?');
			$query->execute([$id]);
			$data=$query->fetch();
		}
		$this->ID=$data['ID'];
		$this->title=$data['title'];
		$this->content=$data['content'];
		$this->author_ID=$data['author_ID'];
		$this->status=$data['status'];
		$this->author=new User();
		if(isset($data['first_name'])) $this->author->first_name=$data['first_name'];
		if(isset($data['last_name'])) $this->author->last_name=$data['first_name'];
	}
	
	public function create($data){

		if(!isset($data['title']{0})) return 'The title is missing';
		$pdo=MySQLDB::connect();

		$query=$pdo->prepare('INSERT INTO posts (title,content) VALUES (?,?)');
		$query->execute([$data['title'],$data['content']]);
	}
	
	public function update($id,$data){

		if(!isset($data['title']{0})) return 'The title is missing';

		$pdo=MySQLDB::connect();

		$query=$pdo->prepare('UPDATE posts SET title=?,content=? WHERE ID=?');
		$query->execute([$data['title'],$data['content'],$id]);
	}
	
	public function delete($id){

		$pdo=MySQLDB::connect();

		$query=$pdo->prepare('UPDATE posts SET status=-1 WHERE ID=?');
		$query->execute([$id]);
	}
	
	public function showDetail(){
		echo '<h3 style="text-align:center" >'."Event Author: ".$this->author_ID.'</h3>';
		echo '<p style="text-align:center" >'.$this->content.'</p>';
		if(isset($_SESSION['user/ID'])){
			if($this->author_ID==$_SESSION['user/ID']) echo '<td><a href="post/edit.php?id='.$this->ID.'">Edit</a></td>';
			else{
				$pdo=MySQLDB::connect();
				$query=$pdo->prepare('SELECT * FROM post_users_joins WHERE post_ID=? AND user_ID=?');
				$query->execute([$this->ID,$_SESSION['user/ID']]);
				if($query->rowCount()==0) echo '<button class="btn btn-primary btn-like">Join this event</button> ';
				else echo '<button class="btn btn-outline-primary btn-like">Unjoin this event</button> ';
			}
		}
	}
	
	public function showPreview(){
		echo '<h3 style="text-align:center" >'.$this->title.'</h3>';
		echo '<br>';
		echo '<p style="text-align:center" >'.$this->content.'</p>';
		echo '<a href="post/detail.php?id='.$this->ID.'">Click for details</a> <br>';
		if(isset($_SESSION['user/ID']) && $this->author_ID==$_SESSION['user/ID']) echo '<a href="admin/posts/edit.php?id='.$this->ID.'">Edit this post</a>';
		echo '<br>';
		echo '<br>';
		echo '<br>';
	}
	
	public function showTableRow(){
		echo '<tr>';
		echo '<td>'.$this->ID.'</td>';
		echo '<td>'.$this->title;
		echo '<td>'.$this->content.'</td>';
		echo '<td>'.$this->status.'</td>';
		echo '<td><a href="admin/posts/edit.php?id='.$this->ID.'">Edit</a></td>';
		echo '<tr>';
	}

	public function like($id){
		$pdo=MySQLDB::connect();
		$query=$pdo->prepare('SELECT * FROM post_users_joins WHERE post_ID=? AND user_ID=?');
		$query->execute([$id,$_SESSION['user/ID']]);
		if($query->rowCount()==0){
			$query=$pdo->prepare('INSERT INTO post_users_joins(post_ID,user_ID) VALUES(?,?)');
			$query->execute([$id,$_SESSION['user/ID']]);
		}else{
			$query=$pdo->prepare('DELETE FROM post_users_joins WHERE post_ID=? AND user_ID=?');
			$query->execute([$id,$_SESSION['user/ID']]);
		}
	}
}