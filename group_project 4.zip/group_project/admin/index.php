<?php
require_once('../settings.php');
require_once('../auth/Auth.php');
if(!Auth::is_logged()) header('location: ../index.php');
require_once('../admin/Admin.php');
Admin::isAdmin('../index.php');

require_once('../template.php');

Template::showHeader('Welcome to the admin section');
?>
<p><a class="btn btn-sm btn-primary" href="admin/users">Manage Users</a></p>
<p><a class="btn btn-sm btn-primary" href="admin/posts">Manage Events</a></p>
<?php

Template::showFooter();