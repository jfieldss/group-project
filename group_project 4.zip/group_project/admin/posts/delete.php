<?php
require_once('../../settings.php');
require_once(APP_ROOT.'/admin/Admin.php');
Admin::isAdmin('../index.php');
require_once('../../Post.php');
$post=new Post();
$post->delete($_GET['id']);
header('location:index.php');