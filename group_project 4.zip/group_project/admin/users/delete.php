<?php
require_once('../../settings.php');
require_once(APP_ROOT.'/admin/Admin.php');
Admin::isAdmin('../index.php');
require_once('../../User.php');
$user=new User();
$user->delete($_GET['id']);
header('location:index.php');