<?php
require_once('../settings.php');
require_once('../auth/Auth.php');
if(!Auth::is_logged()) header('location: ../auth/signin.php');
require_once('../Post.php');
$post=new Post();
//connect to the database
$pdo=MySQLDB::connect();
//select post by id
$query=$pdo->prepare('SELECT * FROM posts WHERE ID=?');
$query->execute([$_GET['id']]);
// check if the post exists
if($query->rowCount()==0)header('location:index.php');
$post=$query->fetch();
// check post author
if($post->author_ID!=$_SESSION['user/ID']) header('location: detail.php?id='.$_GET['id']);
//delete the post
$post->delete($_GET['id']);
header('location:index.php');