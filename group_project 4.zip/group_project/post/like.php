<?php
require_once('../settings.php');
require_once('../Post.php');
// retrieve the post
$post=new Post();
// store like information
$post->like($_GET['id']);
